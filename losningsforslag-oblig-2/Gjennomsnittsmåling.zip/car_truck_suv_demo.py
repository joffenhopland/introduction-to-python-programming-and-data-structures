# This program creates a Car object, a Truck object,
# and an SUV object.
import vehicles
import pickle
import radars

# Constants for the menu choices
NEW_CAR_CHOICE = 1
NEW_TRUCK_CHOICE = 2
NEW_SUV_CHOICE = 3
FIND_VEHICLE_CHOICE = 4
SHOW_VEHICLES_CHOICE = 5
SHOW_VEHICLES_WITH_TICKETS = 6
QUIT_CHOICE = 7

def main():
    # Create empty list for vehicles
    vehicles_list = []
    try:
        with open("Vehicles_File.txt", "rb") as saveFile:
            while True:
                try:
                    vehicles_list.append(pickle.load(saveFile))
                except EOFError:
                    break
            print("done")
    except:
        print("File is not found")
        print("Creating empty file")
        saveFile = open("Vehicles_File.txt", "w")     
        #Add vehicles
        vehicles_list.append(vehicles.Car("Audi", 2001, 7000, 15000, 'YN90106', 4))
        vehicles_list.append(vehicles.Car("Volvo XC60", 2001, 10000, 150000, 'ZZ12345', 4))
        vehicles_list.append(vehicles.Truck("Scania", 2001, 17000, 200000, 'DA86768', 4))
        vehicles_list.append(vehicles.Truck("Volvo F50", 2019, 1600, 250000, 'NB47421', 4))
        vehicles_list.append(vehicles.SUV("Range Rover", 2017, 70000, 000, 'ZZ39125', 4))

    choice = 0
    while choice != QUIT_CHOICE:
        # display the menu.
        display_menu()

        # Get the user's choice.
        try:
            choice = int(input('Enter your choice: '))
        except ValueError:
            pass

        # Perform the selected action.
        if choice == NEW_CAR_CHOICE:
            newVehicle(vehicles_list, "Car")
        elif choice == NEW_TRUCK_CHOICE:
            newVehicle(vehicles_list, "Truck")
        elif choice == NEW_SUV_CHOICE:
            newVehicle(vehicles_list, "SUV")
        elif choice == FIND_VEHICLE_CHOICE:
            searchVehicle(vehicles_list)
        elif choice == SHOW_VEHICLES_CHOICE:
            #show all vehicles
            print('\nThe following cars are in inventory:')
            for item in vehicles_list:
                print(item)
        elif choice == SHOW_VEHICLES_WITH_TICKETS:
            checkForTickets(vehicles_list)
        elif choice == QUIT_CHOICE:
            print('Exiting the program...') 
            save(vehicles_list) 
        else:
            print('Error: invalid selection.')    
    
def save(vehicles_list):
    vehicles_list.sort(key=lambda x: x.make)
    with open("Vehicles_File.txt", "wb") as saveFile:
        for vehicle in vehicles_list:
            pickle.dump(vehicle, saveFile, pickle.HIGHEST_PROTOCOL)

def newVehicle(vehicleList, vehicleType):
    while True:
        try:
            make = str(input("Make: "))       
            year = int(input("Year: "))
            milage = int(input("Milage: "))
            price = float(input("Price: "))
            number = str(input("Enter licenseplate number"))                  

            if vehicleType == "Car":
                special = int(input("Doors: "))
                vehicleList.append(vehicles.Car(make, year, milage, price, number, special))

            elif vehicleType == "Truck":
                special = input("Drive Type: ")
                vehicleList.append(vehicles.Truck(make, year, milage, price, number, special))

            elif vehicleType == "SUV":
                special = int(input("Number of passengers: "))
                vehicleList.append(vehicles.SUV(make, year, milage, price, number, special))
        
        except ValueError:
            print("Please input correct value...")
            break      
        break
    
def searchVehicle(vehicleList):
    vehicleName = input("Name of vehicle: ")
    for vehicle in vehicleList:
        if vehicleName.lower() in vehicle.get_make().lower():
            print(vehicle.__str__())
        else:
            print("Car not in list")
            
def checkForTickets(vehicleList):
    speed_limit = 60
    for x in vehicleList:
        dict = radars.list_speeders("box_a.txt", "box_b.txt", speed_limit, 5)
        if x.get_number() in dict:
            speedingTicket = vehicles.SpeedTicket(x.get_number(), dict[x.get_number()][1], dict[x.get_number()][0], speed_limit)
            if speedingTicket not in x.get_tickets():
                x.set_ticket(speedingTicket)
            print(speedingTicket)
    
# The display_menu function displays a menu.
def display_menu():
    print('        MENU')
    print('1) New car')
    print('2) New truck')
    print('3) New SUV')
    print('4) Find vehicles by make')
    print('5) Show all vehicles')
    print('6) Show all vehicles with speeding ticket')
    print('7) Quit')     

# Call the main function.
if __name__ == '__main__':
      main()
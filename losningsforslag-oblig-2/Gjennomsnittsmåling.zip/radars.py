from datetime import datetime

def fileToDictionary(fileName):
    dict = {}
    fileInput = open(fileName).read().split("\n")

    for x in fileInput:
        data = x.split(", ")
        dict[data[0]] = data[1]
    return dict
        
def list_speeders(filename_a = "box_a.txt", filename_b = "box_b.txt", speed_limit = 60, distance = 5):
    dict_speeders = {}
    dict_a = fileToDictionary(filename_a)
    dict_b = fileToDictionary(filename_b)
    
    for x in dict_a:
        if x in dict_b:
            time = (datetime.strptime(dict_b[x], "%Y-%m-%d %H:%M:%S") - datetime.strptime(dict_a[x], "%Y-%m-%d %H:%M:%S")).total_seconds()
            if (((distance*1000)/time)*3.6) > (speed_limit * 1.05):
                dict_speeders[x] = "{:.3f}".format(((distance*1000)/time)*3.6), dict_a[x]
    return dict_speeders
    
#print(list_speeders("box_a.txt", "box_b.txt", 60, 5))
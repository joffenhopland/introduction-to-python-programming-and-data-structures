class Vehicles:
    def __init__(self, make, year, milage, price, number):
        self.make = str(make)
        self.year = int(year)
        self.milage = int(milage)
        self.price = int(price)
        self.number = str(number)
        self.tickets = []

    def __str__(self):
        return f"Make:  {self.make}  Model:  {self.year}  Milage:  {self.milage}  Price:  {self.price} LicensePlate Number: {self.number}"

    def get_make(self):
        return self.make
    def get_year(self):
        return self.year
    def get_milage(self):
        return self.milage
    def get_price(self):
        return self.price
    def get_number(self):
        return self.number
    def get_tickets(self):
        return self.tickets

    def set_make(self, make):
        self.make = make
    def set_year(self, year):
        self.year = year
    def set_milage(self, milage):
        self.milage = milage
    def set_price(self, price):
        self.price = price
    def set_ticket(self, ticket):
        self.tickets.append(ticket)
        
class Car(Vehicles):
    def __init__(self, make, year, milage, price, number, doors):
        self.doors = int(doors)
        super().__init__(make, year, milage, price, number)
        
    def __str__(self):
        return f"{super().__str__()} Doors: {self.doors}"
        
    def get_doors(self):
        return self.doors
    
    def set_doors(self, doors):
        self.doors = doors
        
class Truck(Vehicles):
    def __init__(self, make, year, milage, price, number, drive_type):
        super().__init__(make, year, milage, price, number)
        self.drive_type = str(drive_type)
        
    def __str__(self):
        return f"{super().__str__()} Drivetype: {self.drive_type}"
    
    def get_drive_type(self):
        return self.drive_type
    
    def set_drive_type(self, drive_type):
        self.drive_type = drive_type
        
class SUV(Vehicles):
    def __init__(self, make, year, milage, price, number, pass_cap):
        super().__init__(make, year, milage, price, number)
        self.pass_cap = int(pass_cap)
        
    def __str__(self):
        return f"{super().__str__()} Number of passengers: {self.pass_cap}"
    
    def get_pass_cap(self):
        return self.pass_cap
    
    def set_pass_cap(self, pass_cap):
        self.pass_cap = pass_cap
        
class SpeedTicket():
    def __init__(self, number, time, speed, speed_limit):
        self.number = number
        self.time = time
        self.speed = speed
        self.speed_limit = speed_limit
        
    def __str__(self):
        return f"\nSpeeding Ticket:\n Registration number: {self.number}\n Time: {self.time}\n Speed: {self.speed}\n Speed Limit: {self.speed_limit}"